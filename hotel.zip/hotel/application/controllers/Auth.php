 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->Ceklogin(); 
	} 

	public function Ceklogin($value='')
	{
		if (!empty($_SESSION['user'])) {
			$this->Leving();
		}else{
			//redirect('/Auth/login');
		}
	}
	public function Register()
	{
		$this->load->view('Auth/register');
	}
	public function addusers()
	{
	
		$data = $_POST;
		$data += array(  	
        'level' => 'tamu'
);
		//var_dump($data); die;
		$this->db->insert('users', $data);

		redirect('/Auth/login');

	}

	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function login()
	{
		$this->load->view('Auth/login');
	}
	public function cekusers()
	{
		//var_dump($_POST);
		$username=$_POST['username'];
		$password=$_POST['password'];

		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$login=$this->db->get('users')->result( );
		
		$_SESSION['user']=$login[0];

		$this->Leving();
/*		var_dump($_SESSION);*/   
	}
	public function Leving()
	{
		if ($_SESSIO['user']->level=="tamu"); {
			redirect('/Tamu/TipeKamar'); 
		}
		if ($_SESSIO['user']->level=="Resepsionis"); {
			redirect('/Tamu/Fasilitas_Hotel'); 
		}
		if ($_SESSIO['user']->level=="Admin"); {
			redirect('/Tamu/Fasilitas_Hotel'); 
		}
	}
	
}    